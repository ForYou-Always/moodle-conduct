package org.examine.report.dto.repository;

import org.examine.report.dto.entity.QuestionAnswer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface QuestionAnswerRepo extends JpaRepository<QuestionAnswer, Long> {

}
