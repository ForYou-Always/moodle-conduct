package org.examine.report.utils;


import java.awt.Color;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.examine.report.contsant.ReportConstants;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.Plot;
import org.jfree.data.general.PieDataset;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRAbstractChartCustomizer;
import net.sf.jasperreports.engine.JRChart;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

@Slf4j
//Specify the package name for customizerClass property in the report.jrxml file.
public class CustomizePieChart extends JRAbstractChartCustomizer  {

	public JasperReport getJasperReport() {
		JasperReport jasperReport = null;	
		try {
			InputStream in  = this.getClass().getClassLoader().getResourceAsStream(ReportConstants.MAIN_REPORT_JRXML);
			jasperReport = JasperCompileManager.compileReport(JRXmlLoader.load(in));
			in.close();
			return jasperReport;
		}catch(Exception e) {
			log.error("Exception while generating report "+e);
		}
		return jasperReport;

	}

	@Override
	public void customize(JFreeChart chart, JRChart jasperChart) {
		// Check the type of plot
		Plot plot = chart.getPlot();
		if (plot instanceof PiePlot) {
			PiePlot piePlot = (PiePlot) plot;   
			Map<String, Color> colorMap = new HashMap<>();
			colorMap.put(ReportConstants.RIGHT_ANSWER,Color.GREEN);
			colorMap.put(ReportConstants.WRONG_ANSWER, Color.RED);     
			PieDataset dataset = piePlot.getDataset();   
			//Assign color to each section of pie chart based on value of key
			for (int i = 0; i < dataset.getItemCount(); i++) {				
				setSectionColor(piePlot, dataset.getKey(i),ReportConstants.RIGHT_ANSWER,colorMap);
				setSectionColor(piePlot, dataset.getKey(i),ReportConstants.WRONG_ANSWER,colorMap);
			}

		}

	}

	private void setSectionColor(PiePlot piePlot, Comparable key, String parterName, Map<String, Color> colorMap) {			
		if(key.toString().contains(parterName)) {
			piePlot.setSectionPaint(key, colorMap.get(parterName));
		}  					
	}
}
