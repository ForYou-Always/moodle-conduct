package org.examine.report.dto.repository;

import org.examine.report.dto.entity.TestCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface TestCategoryRepo extends JpaRepository<TestCategory, Long> {

}
