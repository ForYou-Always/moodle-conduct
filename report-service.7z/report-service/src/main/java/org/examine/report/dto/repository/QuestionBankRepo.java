package org.examine.report.dto.repository;

import org.examine.report.dto.entity.QuestionBank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface QuestionBankRepo  extends JpaRepository<QuestionBank, Long> {

}
