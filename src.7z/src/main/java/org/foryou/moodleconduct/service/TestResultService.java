package org.foryou.moodleconduct.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.foryou.moodleconduct.dao.entity.QuestionAnswer;
import org.foryou.moodleconduct.dao.entity.TestResult;
import org.foryou.moodleconduct.dao.entity.UserAuthorityInfo;
import org.foryou.moodleconduct.dao.repository.TestResultRepository;
import org.foryou.moodleconduct.dao.vo.TestResultVo;
import org.foryou.moodleconduct.utils.storage.CookieSessionStorage;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

@Service
public class TestResultService {

	@Autowired
	private TestResultRepository testResultRepository;

	public TestResult save(TestResultVo testResultVo) {		
		String sessionUser = null;
		if(!ObjectUtils.isEmpty(CookieSessionStorage.get())) {
			sessionUser = CookieSessionStorage.get().getUserName();
		}
		UserAuthorityInfo userAuthorityInfo = UserAuthorityInfo.builder().id(testResultVo.getUserAuthId()).build();
		QuestionAnswer questionAnswer = QuestionAnswer.builder().id(testResultVo.getQuestionId()).build();
		TestResult testResult = TestResult.builder()
				.createUser(sessionUser)
				.updateUser(sessionUser)
				.userAuthorityInfo(userAuthorityInfo)
				.questionAnswer(questionAnswer)
				.build();
		BeanUtils.copyProperties(testResultVo, testResult);
		return testResultRepository.save(testResult);
	}

	public void  deleteById(Long id) {	
		testResultRepository.deleteById(id);
	}

	public List<TestResult> saveAll(List<TestResultVo> testResultVoList) {	
		String sessionUser = null;
		if(!ObjectUtils.isEmpty(CookieSessionStorage.get())) {
			sessionUser = CookieSessionStorage.get().getUserName();
		}
		List<TestResult> testResultList = Collections.emptyList();
		for( TestResultVo testResultVo :   testResultVoList ) {
			UserAuthorityInfo userAuthorityInfo = UserAuthorityInfo.builder().id(testResultVo.getUserAuthId()).build();
			QuestionAnswer questionAnswer = QuestionAnswer.builder().id(testResultVo.getQuestionId()).build();			
			testResultList.add(TestResult.builder()
					.createUser(sessionUser)
					.updateUser(sessionUser)
					.userAuthorityInfo(userAuthorityInfo)
					.questionAnswer(questionAnswer)
					.build());
		};
		return testResultRepository.saveAll(testResultList);
	}
	
	public List<TestResult> findByAssignmentId(Long testId) {
		return testResultRepository.findByTestAssignmentId(testId);
		
	}



}
