package org.foryou.moodleconduct.service;





import java.util.List;
import java.util.Optional;

import org.foryou.moodleconduct.dao.entity.QuestionBank;
import org.foryou.moodleconduct.dao.entity.TestAssignment;
import org.foryou.moodleconduct.dao.entity.UserAuthorityInfo;
import org.foryou.moodleconduct.dao.enumclass.StatusType;
import org.foryou.moodleconduct.dao.repository.TestAssignmentRepository;
import org.foryou.moodleconduct.dao.vo.TestAssignmentVo;
import org.foryou.moodleconduct.utils.storage.CookieSessionStorage;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;



@Service
public class TestAssignmentService {

	@Autowired
	private TestAssignmentRepository testAssignmentRepository;

	public TestAssignment save(TestAssignmentVo testAssignmentVo ) {		
		String sessionUser = null;
		if(!ObjectUtils.isEmpty(CookieSessionStorage.get())) {
			sessionUser = CookieSessionStorage.get().getUserName();			
		}
		QuestionBank questionBank = QuestionBank.builder().id(testAssignmentVo.getQuestionBankId()).build();
		UserAuthorityInfo userAuthorityInfo = UserAuthorityInfo.builder().id(testAssignmentVo.getUserAuthId()).build();
		TestAssignment testAssignment = TestAssignment.builder()
				.createUser(sessionUser).updateUser(sessionUser)
				.status(StatusType.NEW.getType())
				.questionBank(questionBank)
				.userAuthorityInfo(userAuthorityInfo)
				.build();
		BeanUtils.copyProperties(testAssignmentVo, testAssignment);
		return testAssignmentRepository.save(testAssignment);

	}
	
	public TestAssignment findById(Long id) {
		Optional<TestAssignment> testAssignment = testAssignmentRepository.findById(id);
		return testAssignment.isPresent() ? testAssignment.get() : null;
	}
		
	public List<TestAssignment> findAll() {
		List<TestAssignment> testAssignment = testAssignmentRepository.findAll();
		return testAssignment;
	}
	
	public TestAssignment findCompleted() {
		return testAssignmentRepository.findByStatus(StatusType.COMPLETED.getType());
	}	
	
	public void deleteById(Long id) {
		testAssignmentRepository.deleteById(id);
	}

	


}
