package org.foryou.moodleconduct.controller;

import java.util.List;

import org.foryou.moodleconduct.dao.entity.TestAssignment;
import org.foryou.moodleconduct.dao.vo.TestAssignmentVo;
import org.foryou.moodleconduct.service.TestAssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test/assignment")
@CrossOrigin
public class TestAssignmentController {

	@Autowired
	private TestAssignmentService testAssignmentService;

	@PostMapping("/save")
	public TestAssignment save(@RequestBody TestAssignmentVo testAssignmentVo){
		return testAssignmentService.save(testAssignmentVo);
	}

	@GetMapping("/find/{id}")
	public TestAssignment findById(@PathVariable(value="id") long id){
		return testAssignmentService.findById(id);
	}

	@GetMapping("/find/all")
	public List<TestAssignment> findAll(){
		return testAssignmentService.findAll();
	}
	
	@GetMapping("/find/completed")
	public TestAssignment findCompleted(){
		return testAssignmentService.findCompleted();
	}

	@DeleteMapping("/{id}")
	public void  deleteById(@PathVariable(value="id") long id){
		testAssignmentService.deleteById(id);
	}



}
