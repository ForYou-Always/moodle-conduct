package org.foryou.moodleconduct.dao.repository;



import org.foryou.moodleconduct.dao.entity.TestAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;


@Transactional
public interface TestAssignmentRepository extends JpaRepository<TestAssignment, Long> {
	
	public TestAssignment findByStatus(String status);
	
}
