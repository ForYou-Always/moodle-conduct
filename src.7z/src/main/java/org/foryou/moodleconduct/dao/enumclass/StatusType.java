package org.foryou.moodleconduct.dao.enumclass;

import lombok.Getter;

public enum StatusType {
	NEW("New"),
	INPROGRESS("Inprogress"),
	SUBMITTED("Submitted"),
	COMPLETED("Completed"),
	EXPIRED("Expired");	

	@Getter
	private String type;

	StatusType(String type) {
		this.type = type;
	}

}
