package org.foryou.moodleconduct.dao.enumclass;

import lombok.Getter;

public enum QuestionType {
	ANSWERED("Answered"),
	UNANSWERED("Unanswered");	

	@Getter
	private String type;

	QuestionType(String type) {
		this.type = type;
	}
}
