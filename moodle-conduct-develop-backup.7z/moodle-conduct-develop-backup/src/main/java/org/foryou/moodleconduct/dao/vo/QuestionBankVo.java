package org.foryou.moodleconduct.dao.vo;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuestionBankVo {

	private Long id;
	
	private String questionBankName;
}
