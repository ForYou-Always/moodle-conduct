package org.foryou.moodleconduct.dao.vo;




import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestAssignmentVo {

	private Long id;
	
	private Integer questionsCount;
	
	private Boolean inviteSent;
	
	private String status ;
	
	private Boolean expired;
	
	private Timestamp expirationTime;
	
	private Timestamp testStartTime;
	
	private Timestamp testEndTime;
	


}