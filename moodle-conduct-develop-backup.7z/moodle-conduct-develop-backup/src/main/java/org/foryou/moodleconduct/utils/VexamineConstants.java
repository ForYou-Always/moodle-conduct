package org.foryou.moodleconduct.utils;

public class VexamineConstants {

	public static final String SYSTEM_USER = "SYSTEM";
	
	public static final String SUPER_ADMIN_ROLE = "SUPER_ADMIN";
	public static final String MANAGER_ROLE = "MANAGER";
	public static final String CANDIDATE_ROLE = "CANDIDATE";
	
}
