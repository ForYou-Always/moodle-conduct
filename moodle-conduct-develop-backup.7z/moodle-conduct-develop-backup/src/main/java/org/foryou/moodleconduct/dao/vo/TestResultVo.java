package org.foryou.moodleconduct.dao.vo;



import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TestResultVo {

	private Long id;
	
	private Boolean validAnswer;
	
	private String status;

	private Timestamp timeTaken;


}
